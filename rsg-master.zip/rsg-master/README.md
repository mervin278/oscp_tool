# Reverse Shell Generator - rsg

A tool to generate various ways to do a reverse shell

# Usage example

![](example.png)

# Reverse Shell fonts

http://bernardodamele.blogspot.com.br/2011/09/reverse-shells-one-liners.html

http://pentestmonkey.net/cheat-sheet/shells/reverse-shell-cheat-sheet
